package chap02.section4.extras

fun main() {

    val n = 4

    if ((n % 2) == 1) { // 홀수
        println("n is an Odd number")
    }
    if ((n % 2) == 0) { // 짝수
        println("n is an Even number")
    }
}