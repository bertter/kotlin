package chap02.section1

import kotlin.math.PI
import kotlin.math.abs

fun main() {
    val intro: String = "안녕하세요!"
    val num: Int = 20

    println(PI)
    println(abs(-12.6)) // 절댓값을 위해 사용하는 abs( ) 함수

    println("intro: $intro, num: $num")
}


