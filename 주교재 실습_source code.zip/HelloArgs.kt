fun main(args: Array<String>) {
    println(args[0])
    println(args[1])
    println(args[2])
}