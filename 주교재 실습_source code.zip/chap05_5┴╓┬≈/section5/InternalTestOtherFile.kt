package chap05.section5.internal

fun main() {

    val otheric = InternalClass()

    println(otheric.i)
    otheric.icFunc()
}