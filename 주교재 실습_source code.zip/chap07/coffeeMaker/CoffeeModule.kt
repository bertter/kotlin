package chap07.coffeeMaker

interface CoffeeModule {
    fun getThermosiphon() : Thermosiphon
}
