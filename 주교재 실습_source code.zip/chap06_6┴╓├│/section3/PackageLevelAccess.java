package chap06.section3;

public class PackageLevelAccess {
    public static void main(String[] args) {

        // PackageLevelFunctionKt.packageLevelFunc();
        PKLevel.packageLevelFunc();
    }
}
