package chap06.section3;

// 자바의 Customer 클래스
public class Customer {
    public static final String LEVEL = "BASIC";  // static 필드
    public static void login() { // static 메서드
        System.out.println("Login...");
    }
}
